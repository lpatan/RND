jQuery(document).ready(function ($) {
        loadExistingTasks();
    }
);

function loadExistingTasks() {
    var tableHTML = '';
    var i;
    tableHTML += '<table class="tasksTbl">';
    for (i = 0; i < tasks.length; i++) {
        tableHTML += '<tr>';
        tableHTML += '<td>' + tasks[i].name + '</td>' + '<td>' + tasks[i].date + '</td>' + '<td>' + tasks[i].assigned + '</td>';
        tableHTML += '</tr>';
    }
    tableHTML += '</table>';
    $('#list-task-sub-content').html(tableHTML);
}

$("#create-task-btn").click(function () {
    var validationMessage = '';
    if (!isValidInput('#task-name')) {
        validationMessage += 'Please enter Task Name';
        $('#task-name').select();
        $('#task-name').focus();
    }
    if (!isValidInput('#created-date')) {
        if (validationMessage == '') {
            validationMessage += 'Please enter Date';
            $('#created-date').select();
            $('#created-date').focus();
        } else {
            validationMessage += ', Date';
        }
    }
    if (!isValidInput('#assigned-to')) {
        if (validationMessage == '') {
            validationMessage += 'Please enter Assigned To';
            $('#assigned-to').select();
            $('#assigned-to').focus();
        } else {
            validationMessage += ', Assigned To';
        }
    }
    if (validationMessage != '') {
        alert(validationMessage);
        return;
    }
    var task = {
        'name': $('#task-name').val(),
        'date': getFormattedDate_MMDDYYYY(new Date($('#created-date').val() + ' 00:00:00')),
        'assigned': $('#assigned-to').val()
    };
    tasks.unshift(task);
    loadExistingTasks();
    $(':input').val('');
});

function getFormattedDate_MMDDYYYY(date) {
    var month = date.getMonth() + 1;
    var day = date.getDate();
    var year = date.getFullYear();
    return month + '/' + day + '/' + year;
}

function isValidInput(id) {
    return $(id).val().trim() != '';
}
